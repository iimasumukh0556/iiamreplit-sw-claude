import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { Route, Switch } from "wouter";
import App from "./App";
import Usage from "./pages/usage";
import NotFound from "./pages/not-found";
import "./index.css";

function Root() {
  return (
    <Switch>
      <Route path="/" component={App} />
      <Route path="/usage" component={Usage} />
      <Route component={NotFound} />
    </Switch>
  );
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <Root />
  </StrictMode>,
);
