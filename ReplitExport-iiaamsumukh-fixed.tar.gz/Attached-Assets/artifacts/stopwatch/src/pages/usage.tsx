import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link } from "wouter";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  bucketByHour,
  buildLapsAndBreaksCsv,
  downloadCsv,
  formatClockTime,
  formatDuration,
  getActivityIntervals,
  getBreakIntervals,
  getCompletedBreakIntervals,
  getCompletedLapIntervals,
  readUsageState,
  type Interval,
} from "@/lib/usage-data";

type Mode = "activity" | "breaks";

const MODE_OPTIONS: { value: Mode; label: string }[] = [
  { value: "activity", label: "Laps" },
  { value: "breaks", label: "Breaks" },
];

const AXIS_TICKS = ["12am", "6am", "12pm", "6pm"];

const HOUR_SLOT_WIDTH = 60;
const BAR_WIDTH = 38;
const CHART_PLOT_HEIGHT = 180;
const CHART_MARGIN = { top: 8, right: 24, left: 8, bottom: 0 };
const CHART_WIDTH = HOUR_SLOT_WIDTH * 24;
const CHART_HEIGHT =
  CHART_PLOT_HEIGHT + CHART_MARGIN.top + CHART_MARGIN.bottom + 24;

function isTextEntryTarget(target: EventTarget | null): boolean {
  const element = target as HTMLElement | null;
  if (!element) return false;
  return (
    element.isContentEditable ||
    element.tagName === "INPUT" ||
    element.tagName === "TEXTAREA" ||
    element.tagName === "SELECT"
  );
}

function hexWithOpacity(hex: string, opacity: number): string {
  const clean = hex.replace("#", "");
  const r = parseInt(clean.substring(0, 2), 16);
  const g = parseInt(clean.substring(2, 4), 16);
  const b = parseInt(clean.substring(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${opacity})`;
}

function ModeDropdown({
  mode,
  onChange,
}: {
  mode: Mode;
  onChange: (m: Mode) => void;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handleClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [open]);

  const current = MODE_OPTIONS.find((o) => o.value === mode)!;

  return (
    <div className="usage-dropdown" ref={ref}>
      <button
        type="button"
        className="usage-dropdown-trigger"
        onClick={() => setOpen((v) => !v)}
        aria-haspopup="listbox"
        aria-expanded={open}
      >
        {current.label}
        <svg
          className={`usage-dropdown-chevron${open ? " open" : ""}`}
          width="10"
          height="6"
          viewBox="0 0 10 6"
          fill="none"
        >
          <path
            d="M1 1L5 5L9 1"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </button>
      {open && (
        <div className="usage-dropdown-menu" role="listbox">
          {MODE_OPTIONS.map((opt) => (
            <button
              type="button"
              key={opt.value}
              className={`usage-dropdown-item${opt.value === mode ? " selected" : ""}`}
              role="option"
              aria-selected={opt.value === mode}
              onClick={() => {
                onChange(opt.value);
                setOpen(false);
              }}
            >
              <span>{opt.label}</span>
              {opt.value === mode && (
                <svg width="12" height="10" viewBox="0 0 12 10" fill="none">
                  <path
                    d="M1 5L4.5 8.5L11 1.5"
                    stroke="currentColor"
                    strokeWidth="1.6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export default function Usage() {
  const [mode, setMode] = useState<Mode>("activity");
  const [state, setState] = useState(() => readUsageState());

  // Poll localStorage so this page stays in sync with the running stopwatch
  useEffect(() => {
    const id = setInterval(() => setState(readUsageState()), 1000);
    return () => clearInterval(id);
  }, []);

  const activityIntervals = useMemo(
    () => getActivityIntervals(state),
    [state],
  );
  const breakIntervals = useMemo(() => getBreakIntervals(state), [state]);

  const intervals: Interval[] =
    mode === "activity" ? activityIntervals : breakIntervals;
  const buckets = useMemo(() => bucketByHour(intervals), [intervals]);
  const barColor = mode === "activity" ? "#4ade80" : "#FFC900";

  const maxSegments = buckets[0]?.segments.length ?? 1;
  const chartData = useMemo(
    () =>
      buckets.map((b) => {
        const row: Record<string, string | number> = { label: b.label };
        b.segments.forEach((v, i) => {
          row[`seg${i}`] = v;
        });
        return row;
      }),
    [buckets],
  );
  const segmentFill = (index: number) => {
    const shades = [1, 0.6, 0.8, 0.45, 0.7];
    return hexWithOpacity(barColor, shades[index % shades.length]);
  };

  const totalMs = intervals.reduce((sum, iv) => sum + iv.duration, 0);

  // Export only finished records, read fresh from storage (the 1s poll above
  // can be a second stale). The chart keeps using the live intervals.
  const hasExportable = useMemo(
    () => getCompletedLapIntervals(state).length > 0,
    [state],
  );

  const handleExport = useCallback(() => {
    const fresh = readUsageState();
    const laps = getCompletedLapIntervals(fresh);
    if (laps.length === 0) return;
    const csv = buildLapsAndBreaksCsv(
      laps,
      getCompletedBreakIntervals(fresh),
    );
    downloadCsv(`stopwatch-laps-and-breaks-${Date.now()}.csv`, csv);
  }, []);

  useEffect(() => {
    const onKeyDown = (event: globalThis.KeyboardEvent) => {
      if (
        isTextEntryTarget(event.target) ||
        event.repeat ||
        event.altKey ||
        event.shiftKey ||
        !event.ctrlKey ||
        !event.metaKey ||
        event.key.toLowerCase() !== "a"
      ) {
        return;
      }
      if (!hasExportable) return;

      event.preventDefault();
      handleExport();
    };

    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [hasExportable, handleExport]);

  return (
    <div className="usage-app">
      <div className="usage-header">
        <Link href="/" className="usage-back">
          ← Stopwatch
        </Link>
        <h1 className="usage-title">Analytics</h1>
      </div>

      <div className="usage-controls">
        <ModeDropdown mode={mode} onChange={setMode} />
        <button
          type="button"
          className="usage-export-btn"
          disabled={!hasExportable}
          onClick={handleExport}
        >
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <path
              d="M6 1v7M6 8L3.5 5.5M6 8l2.5-2.5M1.5 9.5v1a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1v-1"
              stroke="currentColor"
              strokeWidth="1.3"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          Export CSV
        </button>
      </div>

      <div className="usage-summary">
        <span className="usage-summary-label">
          {mode === "activity" ? "Total tracked" : "Total on break"}
        </span>
        <span className="usage-summary-value" style={{ color: barColor }}>
          {formatDuration(totalMs)}
        </span>
      </div>

      <div className="usage-chart">
        {intervals.length === 0 ? (
          <div className="usage-empty">
            {mode === "activity"
              ? "No activity recorded yet. Press Start on the stopwatch."
              : "No breaks recorded yet."}
          </div>
        ) : (
          <div className="usage-chart-scroll">
            <BarChart
              width={CHART_WIDTH}
              height={CHART_HEIGHT}
              data={chartData}
              margin={CHART_MARGIN}
              barCategoryGap={HOUR_SLOT_WIDTH - BAR_WIDTH}
            >
              <CartesianGrid stroke="#1f1f1f" vertical={false} />
              <XAxis
                dataKey="label"
                ticks={AXIS_TICKS}
                interval={0}
                tick={{ fill: "#666", fontSize: 10, fontFamily: "DM Sans" }}
                axisLine={{ stroke: "#1f1f1f" }}
                tickLine={false}
              />
              <YAxis
                tick={{ fill: "#666", fontSize: 10, fontFamily: "DM Sans" }}
                axisLine={false}
                tickLine={false}
                width={40}
                orientation="right"
                tickFormatter={(v: number) => (v === 0 ? "0" : `${v}m`)}
              />
              <Tooltip
                contentStyle={{
                  background: "#111",
                  border: "0.5px solid #2e2e2e",
                  borderRadius: 6,
                  fontFamily: "DM Sans",
                  fontSize: 12,
                }}
                labelStyle={{ color: "#ccc" }}
                formatter={(value: number) =>
                  value > 0 ? [`${value} min`, mode === "activity" ? "Lap" : "Break"] : [null, null]
                }
              />
              {Array.from({ length: maxSegments }, (_, i) => (
                <Bar
                  key={i}
                  dataKey={`seg${i}`}
                  stackId="hour"
                  fill={segmentFill(i)}
                  stroke="#000"
                  strokeWidth={maxSegments > 1 ? 1.5 : 0}
                  radius={i === maxSegments - 1 ? [4, 4, 0, 0] : [0, 0, 0, 0]}
                  barSize={BAR_WIDTH}
                />
              ))}
            </BarChart>
          </div>
        )}
      </div>

      {mode === "breaks" && breakIntervals.length > 0 && (
        <div className="usage-list">
          <div className="usage-list-header">
            <span>Time</span>
            <span>Duration</span>
          </div>
          <div className="usage-list-body">
            {[...breakIntervals].reverse().map((iv, i) => (
              <div className="usage-list-row" key={i}>
                <span>{formatClockTime(iv.start)}</span>
                <span className="usage-list-duration">
                  {formatDuration(iv.duration)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {mode === "activity" && activityIntervals.length > 0 && (
        <div className="usage-list">
          <div className="usage-list-header">
            <span>Time</span>
            <span>Duration</span>
          </div>
          <div className="usage-list-body">
            {[...activityIntervals].reverse().map((iv, i) => (
              <div className="usage-list-row" key={i}>
                <span>
                  {formatClockTime(iv.start)}
                  <span className="usage-list-name"> · {iv.label}</span>
                </span>
                <span className="usage-list-duration">
                  {formatDuration(iv.duration)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
