const STATE_KEY = "sw_state";

export interface UsageBreak {
  duration: number;
  at: number;
}

export interface UsageLap {
  n: number;
  name: string;
  startAt: number;
  endAt: number;
  split: number;
  breaks: UsageBreak[];
}

export interface UsageState {
  status: "idle" | "running" | "paused";
  laps: UsageLap[];
  currentBreaks: UsageBreak[];
  onBreak: boolean;
  breakStart: number;
  lapStartAt: number;
  liveLapEndAt: number | null;
}

export function readUsageState(): UsageState {
  const empty: UsageState = {
    status: "idle",
    laps: [],
    currentBreaks: [],
    onBreak: false,
    breakStart: 0,
    lapStartAt: 0,
    liveLapEndAt: null,
  };
  try {
    const raw = localStorage.getItem(STATE_KEY);
    if (!raw) return empty;
    const s = JSON.parse(raw);
    if (!s || !s.status) return empty;
    const laps: UsageLap[] = (s.laps ?? [])
      .filter((l: any) => l && l.startAt && l.endAt)
      .map((l: any) => ({
        n: l.n,
        name: l.name ?? "",
        startAt: l.startAt,
        endAt: l.endAt,
        split: typeof l.split === "number" ? l.split : l.endAt - l.startAt,
        breaks: l.breaks ?? [],
      }));
    return {
      status: s.status,
      laps,
      currentBreaks: s.currentBreaks ?? [],
      onBreak: s.onBreak ?? false,
      breakStart: s.breakStart ?? 0,
      lapStartAt: s.lapStartAt ?? 0,
      liveLapEndAt: s.status === "running" ? Date.now() : null,
    };
  } catch {
    return empty;
  }
}

export interface Interval {
  start: number;
  end: number;
  duration: number;
  label: string;
  lapNumber?: number;
}

/**
 * Every activity interval (completed laps + the current in-progress lap, if running).
 * Duration uses the lap's tracked `split` (active running time) rather than the raw
 * wall-clock `endAt - startAt` gap, since the stopwatch can be stopped/resumed mid-lap —
 * that paused wall-clock time must not be counted as tracked activity. The interval's
 * `end` is derived from `start + duration` so hour-bucketing reflects only active time.
 */
export function getActivityIntervals(state: UsageState): Interval[] {
  const intervals: Interval[] = state.laps.map((l) => {
    const duration = typeof l.split === "number" ? l.split : l.endAt - l.startAt;
    return {
      start: l.startAt,
      end: l.startAt + duration,
      duration,
      label: l.name ? `Lap ${l.n} · ${l.name}` : `Lap ${l.n}`,
      lapNumber: l.n,
    };
  });
  if (state.liveLapEndAt !== null && state.lapStartAt) {
    intervals.push({
      start: state.lapStartAt,
      end: state.liveLapEndAt,
      duration: state.liveLapEndAt - state.lapStartAt,
      label: "In progress",
      lapNumber: state.laps.length + 1,
    });
  }
  return intervals;
}

/**
 * Completed laps only, for export. Unlike getActivityIntervals this:
 *  - never includes the in-progress lap, and
 *  - reports each lap's recorded `endAt` (the real moment Lap was pressed)
 *    instead of the derived `start + split`.
 * `duration` stays the lap's active (stopwatch-running) time, so time the
 * stopwatch was stopped inside a lap is in End - Start but not in Duration.
 */
export function getCompletedLapIntervals(state: UsageState): Interval[] {
  return state.laps.map((l) => ({
    start: l.startAt,
    end: l.endAt,
    duration: typeof l.split === "number" ? l.split : l.endAt - l.startAt,
    label: l.name ? `Lap ${l.n} · ${l.name}` : `Lap ${l.n}`,
    lapNumber: l.n,
  }));
}

/**
 * Finished breaks that belong to completed laps, for export. Excludes the
 * ongoing break, breaks logged before Lap 1 is completed, and breaks that
 * started after the last completed lap ended (they belong to the lap still in
 * progress and appear once that lap is completed).
 */
export function getCompletedBreakIntervals(state: UsageState): Interval[] {
  if (state.laps.length === 0) return [];
  const cutoff = Math.max(...state.laps.map((l) => l.endAt));
  const intervals: Interval[] = [];
  state.laps.forEach((l) => {
    (l.breaks ?? []).forEach((b) => {
      if (b.at >= cutoff) return;
      intervals.push({
        start: b.at,
        end: b.at + b.duration,
        duration: b.duration,
        label: "Break",
      });
    });
  });
  return intervals.sort((a, b) => a.start - b.start);
}

/** Every break interval (from completed laps + not-yet-attached breaks + the live break, if active). */
export function getBreakIntervals(state: UsageState): Interval[] {
  const intervals: Interval[] = [];
  state.laps.forEach((l) => {
    (l.breaks ?? []).forEach((b) => {
      intervals.push({
        start: b.at,
        end: b.at + b.duration,
        duration: b.duration,
        label: "Break",
      });
    });
  });
  (state.currentBreaks ?? []).forEach((b) => {
    intervals.push({
      start: b.at,
      end: b.at + b.duration,
      duration: b.duration,
      label: "Break",
    });
  });
  if (state.onBreak && state.breakStart) {
    const now = Date.now();
    intervals.push({
      start: state.breakStart,
      end: now,
      duration: now - state.breakStart,
      label: "Break (ongoing)",
    });
  }
  return intervals.sort((a, b) => a.start - b.start);
}

export interface HourBucket {
  hour: number;
  label: string;
  /** Minutes contributed by each individual interval (lap/break) that overlaps this hour, in order. */
  segments: number[];
  minutes: number;
}

/**
 * Bucket a set of intervals into per-hour stacked segments (0-23).
 * Each interval that overlaps an hour contributes its own segment (in minutes) for that hour,
 * so e.g. two 25-minute laps within the same hour produce two separate stacked segments.
 * Intervals that cross an hour boundary are split proportionally per hour.
 */
export function bucketByHour(intervals: Interval[]): HourBucket[] {
  const perHourSegments: number[][] = Array.from({ length: 24 }, () => []);

  for (const iv of intervals) {
    let cursor = iv.start;
    while (cursor < iv.end) {
      const d = new Date(cursor);
      const hourStart = new Date(d);
      hourStart.setMinutes(0, 0, 0);
      const nextHour = hourStart.getTime() + 60 * 60 * 1000;
      const segEnd = Math.min(iv.end, nextHour);
      const hour = d.getHours();
      const minutes = Math.round(((segEnd - cursor) / 60000) * 10) / 10;
      if (minutes > 0) perHourSegments[hour].push(minutes);
      cursor = segEnd;
    }
  }

  const maxSegments = Math.max(1, ...perHourSegments.map((s) => s.length));

  return perHourSegments.map((segs, hour) => ({
    hour,
    label: formatHourLabel(hour),
    segments: Array.from({ length: maxSegments }, (_, i) => segs[i] ?? 0),
    minutes: Math.round(segs.reduce((sum, m) => sum + m, 0) * 10) / 10,
  }));
}

export function formatHourLabel(hour: number): string {
  const period = hour < 12 ? "am" : "pm";
  const h12 = hour % 12 === 0 ? 12 : hour % 12;
  return `${h12}${period}`;
}

export function formatClockTime(epoch: number): string {
  return new Date(epoch).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
}

export function formatDuration(ms: number): string {
  const totalSeconds = Math.round(ms / 1000);
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds % 60;
  if (m === 0) return `${s}s`;
  return `${m}m ${s}s`;
}

export function formatFullDateTime(epoch: number): string {
  return new Date(epoch).toLocaleString([], {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
  });
}

function csvEscape(value: string): string {
  if (/[",\n]/.test(value)) {
    return `"${value.replace(/"/g, '""')}"`;
  }
  return value;
}

/**
 * Build CSV text combining laps and breaks, sorted chronologically by start time.
 * Callers should pass getCompletedLapIntervals / getCompletedBreakIntervals so
 * only finished records are exported.
 * Columns: Type (Lap/Break), Lap #, Start, End, Duration, and a blank 6th column.
 */
export function buildLapsAndBreaksCsv(
  activityIntervals: Interval[],
  breakIntervals: Interval[],
): string {
  const combined = [
    ...activityIntervals.map((iv) => ({ ...iv, type: "Lap" })),
    ...breakIntervals.map((iv) => ({ ...iv, type: "Break" })),
  ].sort((a, b) => a.start - b.start);

  const header = ["Type", "Lap #", "Start", "End", "Duration", ""].join(",");
  const rows = combined.map((iv) =>
    [
      csvEscape(iv.type),
      iv.lapNumber != null ? String(iv.lapNumber) : "",
      csvEscape(formatFullDateTime(iv.start)),
      csvEscape(formatFullDateTime(iv.end)),
      csvEscape(formatDuration(iv.duration)),
      "",
    ].join(","),
  );
  return [header, ...rows].join("\n");
}

export function downloadCsv(filename: string, csv: string): void {
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
