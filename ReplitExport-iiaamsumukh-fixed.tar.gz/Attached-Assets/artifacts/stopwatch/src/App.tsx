import {
  useCallback,
  useEffect,
  useReducer,
  useRef,
  useState,
  type KeyboardEvent,
} from "react";
import { Link } from "wouter";

type Status = "idle" | "running" | "paused";

interface Break {
  duration: number;
  at: number;
}

interface Lap {
  n: number;
  split: number;
  total: number;
  name: string;
  breaks: Break[];
  startAt: number;
  endAt: number;
}

interface PersistedState {
  status: Status;
  startEpoch: number;
  elapsed: number;
  laps: Lap[];
  lapStart: number;
  lapStartAt: number;
  onBreak: boolean;
  breakStart: number;
  currentBreaks: Break[];
}

const STATE_KEY = "sw_state";
const BACKUP_KEY = "sw_state_backup";
const UNDO_WINDOW_MS = 10 * 60 * 1000;

interface ResetBackup {
  state: PersistedState;
  resetAt: number;
}

function loadBackup(): ResetBackup | null {
  try {
    const raw = localStorage.getItem(BACKUP_KEY);
    if (!raw) return null;
    const b = JSON.parse(raw) as ResetBackup;
    if (!b || !b.state || !b.resetAt) return null;
    if (Date.now() - b.resetAt >= UNDO_WINDOW_MS) {
      localStorage.removeItem(BACKUP_KEY);
      return null;
    }
    return b;
  } catch {
    return null;
  }
}

function fmt(msIn: number): string {
  const ms = msIn < 0 ? 0 : msIn;
  const cs = Math.floor(ms / 10) % 100;
  const s = Math.floor(ms / 1000) % 60;
  const m = Math.floor(ms / 60000) % 60;
  const h = Math.floor(ms / 3600000);
  const pad = (n: number) => String(n).padStart(2, "0");
  if (h > 0) return `${h}:${pad(m)}:${pad(s)}.${pad(cs)}`;
  return `${pad(m)}:${pad(s)}.${pad(cs)}`;
}

function loadState(): PersistedState {
  const fresh: PersistedState = {
    status: "idle",
    startEpoch: 0,
    elapsed: 0,
    laps: [],
    lapStart: 0,
    lapStartAt: 0,
    onBreak: false,
    breakStart: 0,
    currentBreaks: [],
  };
  try {
    const raw = localStorage.getItem(STATE_KEY);
    if (!raw) return fresh;
    const s = JSON.parse(raw) as Partial<PersistedState> | null;
    if (!s || !s.status) return fresh;
    const state: PersistedState = {
      status: s.status,
      startEpoch: s.startEpoch ?? 0,
      elapsed: s.elapsed ?? 0,
      laps: (s.laps ?? []).map((l) => ({
        n: l.n,
        split: l.split,
        total: l.total,
        name: l.name ?? "",
        breaks: l.breaks ?? [],
        startAt: l.startAt ?? 0,
        endAt: l.endAt ?? 0,
      })),
      lapStart: s.lapStart ?? 0,
      lapStartAt: s.lapStartAt ?? 0,
      onBreak: s.onBreak ?? false,
      breakStart: s.breakStart ?? 0,
      currentBreaks: s.currentBreaks ?? [],
    };
    if (state.status === "running") {
      state.elapsed += Date.now() - state.startEpoch;
      state.startEpoch = Date.now();
    }
    return state;
  } catch {
    return fresh;
  }
}

function bestWorst(laps: Lap[]): { best: number; worst: number } {
  if (laps.length < 2) return { best: -1, worst: -1 };
  let bi = 0;
  let wi = 0;
  laps.forEach((l, i) => {
    if (l.split < laps[bi].split) bi = i;
    if (l.split > laps[wi].split) wi = i;
  });
  return { best: laps[bi].n, worst: laps[wi].n };
}

function isTextEntryTarget(target: EventTarget | null): boolean {
  const element = target as HTMLElement | null;
  if (!element) return false;
  return (
    element.isContentEditable ||
    element.tagName === "INPUT" ||
    element.tagName === "TEXTAREA" ||
    element.tagName === "SELECT"
  );
}

export default function App() {
  const stateRef = useRef<PersistedState>(loadState());
  const [, forceRender] = useReducer((x: number) => x + 1, 0);
  const rafRef = useRef<number | null>(null);
  const tickRef = useRef<() => void>(() => {});
  const keyboardHandlersRef = useRef<{
    handleRight: () => void;
    handleLeft: () => void;
    handleBreak: () => void;
  }>({
    handleRight: () => {},
    handleLeft: () => {},
    handleBreak: () => {},
  });

  // pendingNameIdx: a freshly created lap waiting for the inline name prompt
  const [pendingNameIdx, setPendingNameIdx] = useState<number | null>(null);
  const [pendingNameValue, setPendingNameValue] = useState("");
  const pendingInputRef = useRef<HTMLInputElement | null>(null);

  // editingIdx: an existing lap whose name is being inline-edited
  const [editingIdx, setEditingIdx] = useState<number | null>(null);
  const [editingValue, setEditingValue] = useState("");
  const editingInputRef = useRef<HTMLInputElement | null>(null);

  // backup: the pre-reset snapshot available for undo, within a 10-minute window
  const [backup, setBackup] = useState<ResetBackup | null>(() => loadBackup());

  const save = useCallback(() => {
    try {
      localStorage.setItem(STATE_KEY, JSON.stringify(stateRef.current));
    } catch {
      /* noop */
    }
  }, []);

  // Tick every second so the undo countdown updates and auto-expires after 10 minutes,
  // independent of the main RAF loop (which pauses while idle).
  useEffect(() => {
    if (!backup) return;
    const remaining = UNDO_WINDOW_MS - (Date.now() - backup.resetAt);
    if (remaining <= 0) {
      try {
        localStorage.removeItem(BACKUP_KEY);
      } catch {
        /* noop */
      }
      setBackup(null);
      return;
    }
    const id = setInterval(() => {
      if (Date.now() - backup.resetAt >= UNDO_WINDOW_MS) {
        try {
          localStorage.removeItem(BACKUP_KEY);
        } catch {
          /* noop */
        }
        setBackup(null);
      } else {
        forceRender();
      }
    }, 1000);
    return () => clearInterval(id);
  }, [backup]);

  // Single RAF tick — re-renders while either the stopwatch or a break is active
  tickRef.current = () => {
    const s = stateRef.current;
    if (s.status !== "running" && !s.onBreak) {
      rafRef.current = null;
      return;
    }
    forceRender();
    rafRef.current = requestAnimationFrame(() => tickRef.current());
  };

  const ensureTicking = useCallback(() => {
    const s = stateRef.current;
    if ((s.status === "running" || s.onBreak) && rafRef.current === null) {
      rafRef.current = requestAnimationFrame(() => tickRef.current());
    }
  }, []);

  // Kick off ticking on mount if state requires it
  useEffect(() => {
    ensureTicking();
    return () => {
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    };
  }, [ensureTicking]);

  // Persist on tab hide
  useEffect(() => {
    const onVis = () => {
      if (document.hidden && stateRef.current.status === "running") save();
    };
    const onHide = () => {
      if (stateRef.current.status === "running") save();
    };
    document.addEventListener("visibilitychange", onVis);
    window.addEventListener("pagehide", onHide);
    return () => {
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("pagehide", onHide);
    };
  }, [save]);

  // Focus the inline name prompt input when it appears
  useEffect(() => {
    if (pendingNameIdx !== null && pendingInputRef.current) {
      pendingInputRef.current.focus();
    }
  }, [pendingNameIdx]);

  // Focus the inline edit input when it opens
  useEffect(() => {
    if (editingIdx !== null && editingInputRef.current) {
      editingInputRef.current.focus();
      editingInputRef.current.select();
    }
  }, [editingIdx]);

  const closeNamePrompt = () => {
    setPendingNameIdx(null);
    setPendingNameValue("");
  };

  const saveNamePrompt = () => {
    const idx = pendingNameIdx;
    if (idx !== null && stateRef.current.laps[idx]) {
      stateRef.current.laps[idx].name = pendingNameValue.trim();
      save();
    }
    closeNamePrompt();
    forceRender();
  };

  const commitInlineEdit = () => {
    const idx = editingIdx;
    if (idx !== null && stateRef.current.laps[idx]) {
      stateRef.current.laps[idx].name = editingValue.trim();
      save();
    }
    setEditingIdx(null);
    setEditingValue("");
    forceRender();
  };

  const openInlineEdit = (idx: number) => {
    // Commit any in-progress edits/prompts first
    if (editingIdx !== null) commitInlineEdit();
    if (pendingNameIdx !== null) saveNamePrompt();
    setEditingValue(stateRef.current.laps[idx]?.name ?? "");
    setEditingIdx(idx);
  };

  const handleRight = () => {
    const s = stateRef.current;
    if (s.status !== "running") {
      // Start / Resume — auto-end any active break
      if (s.onBreak) {
        const duration = Date.now() - s.breakStart;
        const entry = { duration, at: s.breakStart };
        if (s.laps.length > 0) {
          const lastLap = s.laps[s.laps.length - 1];
          lastLap.breaks = [...(lastLap.breaks ?? []), entry];
        } else {
          s.currentBreaks = [...(s.currentBreaks ?? []), entry];
        }
        s.onBreak = false;
        s.breakStart = 0;
      }
      // A lap's wall-clock start is the moment Start is clicked. This covers the
      // very first Start and the first Start after a Lap press (handleLeft
      // clears lapStartAt). Resuming mid-lap leaves the existing start intact.
      const startedAt = Date.now();
      if (!s.lapStartAt) s.lapStartAt = startedAt;
      s.startEpoch = startedAt;
      s.status = "running";
      closeNamePrompt();
      if (editingIdx !== null) commitInlineEdit();
      save();
      forceRender();
      ensureTicking();
    } else {
      // Stop — freeze stopwatch (break, if active, keeps running independently)
      s.elapsed += Date.now() - s.startEpoch;
      s.status = "paused";
      save();
      forceRender();
      // RAF will self-cancel on next frame if nothing is active
    }
  };

  const handleLeft = () => {
    const s = stateRef.current;
    if (s.status === "running") {
      // Lap
      const now = s.elapsed + (Date.now() - s.startEpoch);
      const split = now - s.lapStart;
      const newIdx = s.laps.length;
      const inheritedBreaks = s.currentBreaks ?? [];
      const nowAt = Date.now();
      // If Start was never clicked since the previous Lap press (watch kept
      // running), fall back to the previous lap's end so the lap still has a
      // valid start and no data is lost.
      const prevEndAt = s.laps.length > 0 ? s.laps[s.laps.length - 1].endAt : 0;
      s.laps = [
        ...s.laps,
        {
          n: newIdx + 1,
          split,
          total: now,
          name: "",
          breaks: inheritedBreaks,
          startAt: s.lapStartAt || prevEndAt || nowAt,
          endAt: nowAt,
        },
      ];
      s.currentBreaks = [];
      s.lapStart = now;
      // The next lap's start is NOT the instant of this Lap press; it is set
      // by the next Start click (see handleRight).
      s.lapStartAt = 0;
      save();
      // Show inline name prompt for the just-created lap
      setPendingNameValue("");
      setPendingNameIdx(newIdx);
      forceRender();
    } else if (s.status === "paused") {
      // Reset — keep a 10-minute undo backup in case this was a mistake
      const hadData = s.laps.length > 0 || s.elapsed > 0;
      if (hadData) {
        const snapshot: ResetBackup = {
          state: JSON.parse(JSON.stringify(s)),
          resetAt: Date.now(),
        };
        try {
          localStorage.setItem(BACKUP_KEY, JSON.stringify(snapshot));
        } catch {
          /* noop */
        }
        setBackup(snapshot);
      }
      stateRef.current = {
        status: "idle",
        startEpoch: 0,
        elapsed: 0,
        laps: [],
        lapStart: 0,
        lapStartAt: 0,
        onBreak: false,
        breakStart: 0,
        currentBreaks: [],
      };
      try {
        localStorage.removeItem(STATE_KEY);
      } catch {
        /* noop */
      }
      closeNamePrompt();
      setEditingIdx(null);
      setEditingValue("");
      forceRender();
    }
  };

  const handleUndoReset = () => {
    if (!backup) return;
    stateRef.current = backup.state;
    save();
    try {
      localStorage.removeItem(BACKUP_KEY);
    } catch {
      /* noop */
    }
    setBackup(null);
    forceRender();
    ensureTicking();
  };

  const handleBreak = () => {
    const s = stateRef.current;
    if (s.status === "idle") return;

    if (!s.onBreak) {
      s.onBreak = true;
      s.breakStart = Date.now();
      save();
      forceRender();
      ensureTicking();
    } else {
      const duration = Date.now() - s.breakStart;
      const entry = { duration, at: s.breakStart };
      if (s.laps.length > 0) {
        const lastLap = s.laps[s.laps.length - 1];
        lastLap.breaks = [...(lastLap.breaks ?? []), entry];
      } else {
        s.currentBreaks = [...(s.currentBreaks ?? []), entry];
      }
      s.onBreak = false;
      s.breakStart = 0;
      save();
      forceRender();
    }
  };

  keyboardHandlersRef.current = { handleRight, handleLeft, handleBreak };

  // Keyboard shortcuts mirror the primary controls. Support either modifier so
  // the same combinations work naturally on macOS and Windows/Linux.
  useEffect(() => {
    const onKeyDown = (event: globalThis.KeyboardEvent) => {
      if (isTextEntryTarget(event.target) || event.altKey) return;
      if (!event.metaKey && !event.ctrlKey) return;
      if (event.repeat) return;

      const key = event.key.toLowerCase();
      if (key === "s") {
        event.preventDefault();
        keyboardHandlersRef.current.handleRight();
      } else if (
        key === "l" &&
        event.ctrlKey &&
        event.metaKey &&
        !event.shiftKey
      ) {
        event.preventDefault();
        keyboardHandlersRef.current.handleLeft();
      } else if (key === "b") {
        event.preventDefault();
        keyboardHandlersRef.current.handleBreak();
      }
    };

    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  // ── Derived view data ──
  const s = stateRef.current;
  const running = s.status === "running";
  const isIdle = s.status === "idle";
  const curElapsed = running ? s.elapsed + (Date.now() - s.startEpoch) : s.elapsed;
  const curSplit = curElapsed - s.lapStart;
  const { best: bestN, worst: worstN } = bestWorst(s.laps);

  const hasData = s.laps.length > 0 || s.status !== "idle";
  const leftLabel = running ? "Lap" : "Reset";
  const rightLabel = running ? "Stop" : "Start";

  // Break button state classes & label
  let breakClass = "btn-break";
  let breakLabel = "Take Break";
  let breakDisabled = true;
  if (!isIdle) {
    if (s.onBreak) {
      breakClass = "btn-break on-break";
      breakLabel = `End Break  ${fmt(Date.now() - s.breakStart)}`;
      breakDisabled = false;
    } else {
      breakClass = "btn-break active";
      breakLabel = "Take Break";
      breakDisabled = false;
    }
  }

  const lapsReversed = [...s.laps].map((l, i) => ({ lap: l, idx: i })).reverse();

  const undoRemainingMs = backup
    ? Math.max(0, UNDO_WINDOW_MS - (Date.now() - backup.resetAt))
    : 0;
  const showUndo = isIdle && backup !== null && undoRemainingMs > 0;
  const undoCountdown = (() => {
    const totalSec = Math.ceil(undoRemainingMs / 1000);
    const m = Math.floor(totalSec / 60);
    const sec = totalSec % 60;
    return `${m}:${String(sec).padStart(2, "0")}`;
  })();

  const onPromptKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") saveNamePrompt();
    else if (e.key === "Escape") closeNamePrompt();
  };
  const onEditKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" || e.key === "Escape") {
      (e.currentTarget as HTMLInputElement).blur();
    }
  };

  return (
    <div className="app">
      <Link href="/usage" className="usage-link" aria-label="View usage graph">
        Analytics ↗
      </Link>

      <div className="timer-wrap">
        <div className="timer" aria-live="off" aria-label="Stopwatch timer">
          {fmt(curElapsed)}
        </div>
      </div>

      <div className="btn-row">
        <button
          className={`btn btn-left${isIdle ? " disabled" : ""}`}
          aria-label={leftLabel}
          onClick={handleLeft}
        >
          {leftLabel}
        </button>

        <button
          className={breakClass}
          onClick={handleBreak}
          disabled={breakDisabled}
        >
          {breakLabel}
        </button>

        <button
          className={`btn btn-right${running ? " stop" : ""}`}
          aria-label={rightLabel}
          onClick={handleRight}
        >
          {rightLabel}
        </button>
      </div>

      {showUndo && (
        <button type="button" className="undo-banner" onClick={handleUndoReset}>
          <span>↺ Undo reset</span>
          <span className="undo-countdown">{undoCountdown}</span>
        </button>
      )}

      {hasData ? (
        <div className="lap-section">
          <div className="lap-header">
            <span>Lap</span>
            <span>Split</span>
            <span>Total</span>
          </div>
          <div className="lap-list" role="list">
            {!isIdle &&
              (s.currentBreaks ?? []).map((b, bi) => (
                <div
                  key={`cb-${bi}`}
                  className="break-row"
                  role="listitem"
                >
                  <span className="break-label">Break</span>
                  <span>{fmt(b.duration)}</span>
                  <span></span>
                </div>
              ))}

            {!isIdle && (
              <div className="lap-row current" role="listitem">
                <div className="lap-label-cell">
                  <span className="lap-num">Lap {s.laps.length + 1}</span>
                </div>
                <span>{fmt(curSplit)}</span>
                <span>{fmt(curElapsed)}</span>
              </div>
            )}

            {pendingNameIdx !== null && (
              <div className="name-prompt" role="listitem">
                <span className="name-prompt-label">
                  Name lap {pendingNameIdx + 1}
                </span>
                <input
                  ref={pendingInputRef}
                  className="name-prompt-input"
                  type="text"
                  maxLength={40}
                  placeholder="e.g. warm-up, sprint…"
                  autoComplete="off"
                  value={pendingNameValue}
                  onChange={(e) => setPendingNameValue(e.target.value)}
                  onKeyDown={onPromptKey}
                />
                <button
                  className="name-prompt-save"
                  onClick={saveNamePrompt}
                >
                  Done
                </button>
              </div>
            )}

            {lapsReversed.map(({ lap, idx }) => {
              const cls =
                lap.n === bestN ? "best" : lap.n === worstN ? "worst" : "";
              const isEditing = editingIdx === idx;
              const breakRows =
                lap.breaks && lap.breaks.length > 0
                  ? lap.breaks.map((b, bi) => (
                      <div
                        key={`b-${idx}-${bi}`}
                        className="break-row"
                        role="listitem"
                      >
                        <span className="break-label">Break</span>
                        <span>{fmt(b.duration)}</span>
                        <span></span>
                      </div>
                    ))
                  : null;
              return (
                <div key={`lap-${idx}`}>
                  {breakRows}
                  <div className={`lap-row ${cls}`} role="listitem">
                    <div className="lap-label-cell">
                      <span className="lap-num">Lap {lap.n}</span>
                      {isEditing ? (
                        <input
                          ref={editingInputRef}
                          className="lap-name-input"
                          type="text"
                          maxLength={40}
                          autoComplete="off"
                          placeholder="add a name…"
                          value={editingValue}
                          onChange={(e) => setEditingValue(e.target.value)}
                          onBlur={commitInlineEdit}
                          onKeyDown={onEditKey}
                        />
                      ) : (
                        <button
                          type="button"
                          className={`lap-name-display${
                            lap.name ? "" : " placeholder"
                          }`}
                          onClick={() => openInlineEdit(idx)}
                        >
                          <i className="pencil">✎</i>
                          {lap.name ? lap.name : "add name"}
                        </button>
                      )}
                    </div>
                    <span>{fmt(lap.split)}</span>
                    <span>{fmt(lap.total)}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        <div className="empty-state">press start</div>
      )}
    </div>
  );
}
