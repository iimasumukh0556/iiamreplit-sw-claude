// Variables used by Scriptable.
// These must be at the very top of the file. Do not edit.
// icon-color: deep-brown; icon-glyph: magic;
// ══════════════════════════════════════
// SINCE 18 — Days of Potential Wasted
// Paste into Scriptable on iOS
// ══════════════════════════════════════

const SINCE_DATE = new Date("2024-10-04T00:00:00");

const now = new Date();
const diffMs = now.getTime() - SINCE_DATE.getTime();
const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));

const widget = new ListWidget();
widget.backgroundColor = new Color("#0E0E0E");
widget.setPadding(16, 16, 16, 16);

// Background gradient
const grad = new LinearGradient();
grad.colors = [new Color("#141414"), new Color("#0E0E0E")];
grad.locations = [0, 1];
widget.backgroundGradient = grad;

// Line 1 — "{days} days" in same bold font
const row = widget.addStack();
row.layoutHorizontally();
row.centerAlignContent();

const countText = row.addText(String(days));
countText.textColor = new Color("#D4C3A5");
countText.font = Font.boldSystemFont(48);
countText.minimumScaleFactor = 0.5;

const daysLabel = row.addText(" Days ");
daysLabel.textColor = new Color("#D4C3A5");
daysLabel.font = Font.boldSystemFont(48);
daysLabel.minimumScaleFactor = 0.5;

widget.addSpacer(8);



// Line 2 — "Potential Wasted."
const heading = widget.addText("Potential Wasted.");
heading.textColor = new Color("#6B6560");
heading.font = Font.boldSystemFont(22);
heading.leftAlignText();
heading.minimumScaleFactor = 0.6;

widget.addSpacer(6);

// Line 3 — "Virgin Since 4th October 2024."
const caption = widget.addText("Virgin Since 4th October 2024.");
caption.textColor = new Color("#6B6560");
caption.font = Font.boldSystemFont(11);
caption.leftAlignText();
caption.minimumScaleFactor = 0.6;

Script.setWidget(widget);
widget.presentMedium();