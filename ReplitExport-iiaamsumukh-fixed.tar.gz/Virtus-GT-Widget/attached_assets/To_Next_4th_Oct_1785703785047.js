// Variables used by Scriptable.
// These must be at the very top of the file. Do not edit.
// icon-color: deep-brown; icon-glyph: magic;
// ══════════════════════════════════════
// SINCE 18 — Days Until Next October
// Paste into Scriptable on iOS
// ══════════════════════════════════════

const now = new Date();
let year = now.getFullYear();

// Target: October 4 of current year (or next if already past)
let target = new Date(year, 9, 4); // Month 9 = October (0-indexed)
if (now >= target) {
  year += 1;
  target = new Date(year, 9, 4);
}

const diffMs = target.getTime() - now.getTime();
const days = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

const widget = new ListWidget();
widget.backgroundColor = new Color("#0E0E0E");
widget.setPadding(16, 16, 16, 16);

// Gradient
const grad = new LinearGradient();
grad.colors = [new Color("#1A1208"), new Color("#0E0E0E")];
grad.locations = [0, 1];
widget.backgroundGradient = grad;

// Eyebrow
const eyebrow = widget.addText("DAYS UNTIL");
eyebrow.textColor = new Color("#6B6560");
eyebrow.font = new Font("Menlo", 8);
eyebrow.leftAlignText();

widget.addSpacer(6);

// Day count
const count = widget.addText(String(days));
count.textColor = new Color("#C8A96E");
count.font = Font.boldSystemFont(42);
count.leftAlignText();
count.minimumScaleFactor = 0.5;

widget.addSpacer(4);

// Target date
const sub = widget.addText(`4 Oct ${year}`);
sub.textColor = new Color("#4A4A42");
sub.font = Font.systemFont(9);
sub.leftAlignText();

Script.setWidget(widget);
widget.presentSmall();