// Variables used by Scriptable.
// These must be at the very top of the file. Do not edit.
// icon-color: deep-brown; icon-glyph: car;
// ══════════════════════════════════════
// VIRTUS GT — Price Widget
// Paste into Scriptable on iOS
// ══════════════════════════════════════

const widget = new ListWidget();
widget.backgroundColor = new Color("#0E0E0E");
widget.setPadding(16, 16, 16, 16);

// Background gradient
const grad = new LinearGradient();
grad.colors = [new Color("#1A1208"), new Color("#0E0E0E")];
grad.locations = [0, 1];
widget.backgroundGradient = grad;

// H1 — "Virtus GT"
const heading1 = widget.addText("Virtus GT");
heading1.textColor = new Color("#C8A96E");
heading1.font = Font.boldSystemFont(20);
heading1.leftAlignText();
heading1.minimumScaleFactor = 0.6;

widget.addSpacer(10);

// H2 — Price in Rupees
const heading2 = widget.addText("₹14,50,000");
heading2.textColor = new Color("#D4C3A5");
heading2.font = Font.boldSystemFont(36);
heading2.leftAlignText();
heading2.minimumScaleFactor = 0.5;

widget.addSpacer(6);

// H3 — Price in Dollars
const heading3 = widget.addText("($19,000)");
heading3.textColor = new Color("#6B6560");
heading3.font = Font.boldSystemFont(16);
heading3.leftAlignText();
heading3.minimumScaleFactor = 0.6;

Script.setWidget(widget);
widget.presentSmall();
